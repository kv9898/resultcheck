# This file is part of the standard testthat setup
library(testthat)
library(resultcheck)

test_check("resultcheck")
